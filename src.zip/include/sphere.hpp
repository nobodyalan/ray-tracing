#ifndef SPHERE_H
#define SPHERE_H

#include "object3d.hpp"
#include <vecmath.h>
#include <cmath>

// TODO: Implement functions and add more fields as necessary

class Sphere : public Object3D
{
public:
    Sphere()
    {
        // unit ball at the center
        center = Vector3f(0, 0, 0);
        radius = 1.0f;
    }

    Sphere(const Vector3f &_center, float _radius, Material *material) : Object3D(material)
    {
        center = _center;
        radius = _radius;
    }

    ~Sphere() override = default;

    bool intersect(const Ray &r, Hit &h, float tmin) override
    {
        Vector3f L = r.getOrigin() - center;
        Vector3f D = r.getDirection();

        // Optimized algebraic method.
        // Using a = D.D, b' = D.L, c = L.L - R^2 to solve at^2 + 2b't + c = 0
        float a = D.squaredLength();
        float b_prime = Vector3f::dot(D, L);
        float c = L.squaredLength() - radius * radius;

        float discriminant = b_prime * b_prime - a * c;

        // No intersection if discriminant is negative
        if (discriminant < 0)
        {
            return false;
        }

        float sqrt_d = sqrtf(discriminant);

        // Find the closest valid t. Since a > 0, t1 <= t2.
        float t = (-b_prime - sqrt_d) / a;
        if (t < tmin)
        {
            t = (-b_prime + sqrt_d) / a;
        }

        // Check if the intersection is valid and closer than previously recorded hit
        if (t >= tmin && t < h.getT())
        {
            Vector3f hitPoint = r.pointAtParameter(t);
            Vector3f normal = (hitPoint - center).normalized();
            h.set(t, material, normal);
            return true;
        }

        return false;
    }

protected:
    Vector3f center;
    float radius;
};

#endif
