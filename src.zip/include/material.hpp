#ifndef MATERIAL_H
#define MATERIAL_H

#include <cassert>
#include <vecmath.h>

#include "ray.hpp"
#include "hit.hpp"
#include <iostream>

// TODO: Implement Shade function that computes Phong introduced in class.
class Material
{
public:
    explicit Material(const Vector3f &d_color, const Vector3f &s_color = Vector3f::ZERO, float s = 0) : diffuseColor(d_color), specularColor(s_color), shininess(s)
    {
    }

    virtual ~Material() = default;

    virtual Vector3f getDiffuseColor() const
    {
        return diffuseColor;
    }

    virtual Vector3f getSpecularColor() const
    {
        return specularColor;
    }

    Vector3f Shade(const Ray &ray, const Hit &hit,
                   const Vector3f &dirToLight, const Vector3f &lightColor)
    {
        Vector3f shaded = Vector3f::ZERO;
        //
        Material *m = hit.getMaterial();
        Vector3f N = hit.getNormal();
        Vector3f V = -ray.getDirection();
        Vector3f R = (2 * Vector3f::dot(N, dirToLight) * N - dirToLight).normalized();

        // 【改动】修改了高光计算的点乘项，将原来的 Vector3f::dot(N, R) 改为了 Vector3f::dot(V, R)
        // Phong模型中高光项是视线方向(V)与反射方向(R)的夹角余弦，而之前的代码误用了法线(N)进行计算
        shaded = lightColor * (m->getDiffuseColor() * std::max(0.0f, Vector3f::dot(N, dirToLight)) +
                               m->getSpecularColor() * powf(std::max(0.0f, Vector3f::dot(V, R)), shininess));
        return shaded;
    }

protected:
    Vector3f diffuseColor;
    Vector3f specularColor;
    float shininess;
};

#endif // MATERIAL_H
